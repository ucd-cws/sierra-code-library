A simple iTunes remote controller tool.

Run 'itunescontroller' on the mac with the iTunes that you want to control.
It only works on mac os because it uses the osascript utility to manipulate
iTunes via a few applescript commands.

Run the 'remote' on any other host. It does a few remote control operations.

