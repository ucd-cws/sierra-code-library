'''
Created on Feb 5, 2012

@author: Nick
'''


__all__ = ["log"]